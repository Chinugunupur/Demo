import sqlite3
import pandas as pd
conn = sqlite3.connect(r"C:\Users\Srikant Padhy\uploadfile\uploadfile\book.db")
c = conn.cursor()
def read_from_db():
    c.execute("select * from uploadpdf_book;")
    for row in c.fetchall():
        #data = c.fetchall()
        print(row)
read_from_db()

# query = "SELECT * FROM uploadpdf_book"
# daf = pd.read_sql(query, conn)
# print(daf)

# s = c.execute("select * from uploadpdf_book")

# def createtable():
#     c.execute('CREATE TABLE uploadpdf_book(contact_id INTEGER PRIMARY KEY);')
# def insertable():
#     c.execute("ALTER TABLE uploadpdf_book ADD COLUMN scanpdf CHAR(25);")
# insertable()
#createtable()