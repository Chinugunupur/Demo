from django.shortcuts import render,redirect
from .forms import BookForm
from .models import Book


# Create your views here.

def book_list(request):
    return render(request, 'book_list.html')
    # books = Book.pdf
    # print("=============")
    # print(books.value_from_object())
    # books = Book.objcets.all()
    # return render(request, 'book_list.html',{ 'books':books})
def upload_book(request):
    if request.method == 'POST':
        print(request.FILES)
        form = BookForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('book_list')
    else:
        form = BookForm()
    return render(request, 'upload_book.html',{'form':form})
