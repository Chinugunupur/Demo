from django.apps import AppConfig


class UploadpdfConfig(AppConfig):
    name = 'uploadpdf'
